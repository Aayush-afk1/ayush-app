function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '2rem' }}>
      <h1>Welcome to Aakriti 🌸</h1>
      <p>This is a PWA app built with React and Vite.</p>
    </div>
  );
}

export default App;